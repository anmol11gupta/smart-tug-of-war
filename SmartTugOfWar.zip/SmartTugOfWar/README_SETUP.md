# Smart Tug of War - Unity prototype (setup guide)

Works with Unity 2021.3 LTS, 2022.3 LTS or Unity 6, 3D project (Built-in or URP). Windows PC target.

## 1. Create the project
1. Unity Hub > New project > "3D (Built-in Render Pipeline)" or "Universal 3D" > name it SmartTugOfWar.
2. In Unity, open the Project window. Copy the folders from this zip's `Assets` folder INTO your project's `Assets` folder
   (you should end with `Assets/Scripts/*.cs` and `Assets/Resources/Questions/questions.json`).
3. **Input setting (important):** Edit > Project Settings > Player > Other Settings > **Active Input Handling = Both**
   (Unity restarts). Without this, keyboard shortcuts and clicks can fail in Unity 6.

## 2. Build the scene (only ONE manual step)
1. File > New Scene > Basic (or keep the default SampleScene).
2. Hierarchy: right-click > Create Empty. Rename it `GameBootstrap`.
3. Select it, Inspector > Add Component > **GameBootstrap**.
4. Save the scene (Ctrl+S) as `Assets/Scenes/Main.unity`. Press **Play**.

Everything else (camera, light, playground, kids, rope, all menus, buttons, sounds) is created by code when you press Play,
so there are no other Inspector fields to assign. GameBootstrap has 4 optional tweakable fields:
`kidsPerTeam` (4), `ropeMaxOffset` (3.2), `cameraPosition`, `cameraLookAt`.

## 3. Folder structure
```
Assets/
  Scenes/Main.unity                (you save this)
  Resources/
    Questions/questions.json       (240 questions: English, EVS, GK for each class)
    Questions/<any more>.json      (drop extra files here - they load automatically)
    Audio/                         (optional: click, correct, wrong, rope, victory, music)
    Illustrations/                 (reserved for future pictures)
  Scripts/
    GameBootstrap.cs   attach to the ONE empty GameObject (the only manual attach)
    GameManager.cs     game state + rules (no UI)             [auto-added]
    ScoreManager.cs    scores, winning score, no overflow     [auto-added]
    QuestionManager.cs loads JSON, picks 2 different questions[auto-added]
    MathQuestionGenerator.cs  unlimited Maths for all classes
    QuestionData.cs    data classes + enums
    RopeController.cs  rope, marker, smooth sliding           [auto-added]
    TeamController.cs  a team of kids                         [auto-created]
    KidCharacter.cs    cartoon kid + code animations
    TeacherController.cs  keyboard + button enable/disable    [auto-added]
    UIManager.cs / UIKit.cs / ButtonPop.cs  all screens built in code
    AudioManager.cs    generated music/sfx, volume, mute      [auto-added]
    PlaygroundBuilder.cs / CloudMover.cs / Sway.cs   scenery
    GameUtil.cs        helpers
```

## 4. How the teacher plays
PLAY > class > subject > team names, rounds, winning score > START MATCH.
START ROUND (S) > SHOW QUESTION (Q) > read aloud > RED CORRECT (R) or BLUE CORRECT (B)
(or NO POINT / SKIP (X)) > REVEAL ANSWER (A) any time > NEXT ROUND (N). PAUSE (P). Space = next sensible step.
RESET MATCH and END GAME need a second click within 3 seconds (prevents accidents).

## 5. Test checklist
1. Menu animates; PLAY > LKG > MATHS > START MATCH works; BACK buttons work.
2. START ROUND: only SHOW QUESTION is enabled. Show it: both panels appear (different questions, same subject).
3. Click RED CORRECT: scoreboard 1-0, rope slides LEFT, red kids jump, blue kids look "oops". RED/BLUE/SKIP now grey (no double scoring).
4. NEXT ROUND is the only active button; press it. Try keys S Q R B N.
5. Give red 5 points (winning score): rope reaches red line, victory screen with trophy, confetti, sound, losers clap.
6. PLAY AGAIN / MAIN MENU. Test PAUSE overlay (volume +/-, mute).
7. Set rounds to 3 and winning score 5: after round 3 button says FINISH GAME; higher score wins, equal = tie screen.
8. Mixed mode: each round picks one subject for BOTH teams.

## 6. Adding questions
Open `questions.json` (or add a new .json in Resources/Questions). Each entry:
```
{"classLevel":"Class1","subject":"EVS","question":"Which animal has a trunk?",
 "options":["Elephant","Giraffe","Lion","Horse"],"correctIndex":0,"visual":""}
```
classLevel: LKG, UKG, Class1, Class2. subject: Mathematics, English, EVS, GeneralKnowledge.
`visual` is optional big text under the question; Unity rich text works, e.g. `<size=90><color=#E53935>\u25CF</color></size>`.
Options are shuffled automatically. Invalid entries are skipped with a Console warning.

## 7. Replacing placeholders
* Kids: KidCharacter builds primitives. Later replace with real models + Animator.
* Sounds: put click/correct/wrong/rope/victory/music (.wav/.mp3/.ogg) in Assets/Resources/Audio and they replace generated sounds.

## 8. Build the .exe
File > Build Profiles / Build Settings > Windows > add the open scene > Build. If any object looks pink, use a Built-in or URP template (both work).

## Troubleshooting
* Text looks small/odd: the game uses the OS font (Comic Sans MS, else Arial).
* Keys do nothing: set Active Input Handling to Both (step 1.3).
* Console error after pressing Play: copy the first red line and send it to me.
