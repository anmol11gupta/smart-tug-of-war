using UnityEngine;

public class Sway : MonoBehaviour
{
    public float amplitude = 4f, speed = 1.5f, phase;
    Quaternion baseRot;
    void Awake() { baseRot = transform.localRotation; }
    void Update()
    {
        transform.localRotation = baseRot * Quaternion.Euler(0, 0, Mathf.Sin(Time.time * speed + phase) * amplitude);
    }
}
