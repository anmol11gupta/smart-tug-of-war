using System.Collections.Generic;
using System.Text;
using UnityEngine;

/// Unlimited, class-appropriate Maths questions (so Maths never runs out).
public static class MathQuestionGenerator
{
    static readonly string[] Words = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" };
    static readonly string[] ShapeNames = { "Circle", "Square", "Triangle", "Rectangle" };
    static readonly string[] ShapeGlyphs = { "\u25CF", "\u25A0", "\u25B2", "\u25AC" };

    public static int KindCount(ClassLevel c) { return 4; }

    public static QuestionData Make(ClassLevel c, int kind)
    {
        switch (c)
        {
            case ClassLevel.LKG: return LKG(kind);
            case ClassLevel.UKG: return UKG(kind);
            case ClassLevel.Class1: return Class1(kind);
            default: return Class2(kind);
        }
    }

    static QuestionData LKG(int kind)
    {
        ClassLevel c = ClassLevel.LKG;
        if (kind == 0)
        {
            int n = Random.Range(1, 10);
            StringBuilder sb = new StringBuilder("<size=60><color=#E53935>");
            for (int i = 0; i < n; i++) sb.Append("\u25CF ");
            sb.Append("</color></size>");
            return Num(c, "Count the apples. How many?", n, sb.ToString());
        }
        if (kind == 1)
        {
            int n = Random.Range(1, 11);
            return Num(c, "Which number is \"" + Words[n] + "\"?", n, "");
        }
        if (kind == 2)
        {
            int a = Random.Range(1, 11), b = Random.Range(1, 11);
            while (b == a) b = Random.Range(1, 11);
            return Choice(c, "Which number is BIGGER?", new string[] { a.ToString(), b.ToString() }, (a > b) ? 0 : 1, "");
        }
        int s = Random.Range(0, 4);
        return Shuffled(c, "What shape is this?", ShapeNames, ShapeNames[s],
            "<size=90><color=#FB8C00>" + ShapeGlyphs[s] + "</color></size>");
    }

    static QuestionData UKG(int kind)
    {
        ClassLevel c = ClassLevel.UKG;
        if (kind == 0)
        {
            int a = Random.Range(1, 10), b = Random.Range(1, 11 - a);
            return Num(c, a + " + " + b + " = ?", a + b, "");
        }
        if (kind == 1)
        {
            int a = Random.Range(2, 11), b = Random.Range(1, a);
            return Num(c, a + " - " + b + " = ?", a - b, "");
        }
        if (kind == 2)
        {
            int start = Random.Range(1, 9), hide = Random.Range(1, 4);
            return Num(c, "What is the missing number?", start + hide, Sequence(start, 1, hide));
        }
        int x = Random.Range(1, 21), y = Random.Range(1, 21);
        while (y == x) y = Random.Range(1, 21);
        bool bigger = Random.value < 0.5f;
        int correct = bigger ? (x > y ? 0 : 1) : (x < y ? 0 : 1);
        return Choice(c, bigger ? "Which number is BIGGER?" : "Which number is SMALLER?",
            new string[] { x.ToString(), y.ToString() }, correct, "");
    }

    static QuestionData Class1(int kind)
    {
        ClassLevel c = ClassLevel.Class1;
        if (kind == 0)
        {
            int a = Random.Range(10, 40), b = Random.Range(5, 20);
            return Num(c, a + " + " + b + " = ?", a + b, "");
        }
        if (kind == 1)
        {
            int a = Random.Range(15, 60), b = Random.Range(3, 14);
            return Num(c, a + " - " + b + " = ?", a - b, "");
        }
        if (kind == 2)
        {
            int[] steps = { 2, 5, 10 };
            int step = steps[Random.Range(0, 3)];
            int start = step * Random.Range(1, 5), hide = Random.Range(1, 4);
            return Num(c, "What is the missing number?", start + hide * step, Sequence(start, step, hide));
        }
        int p = Random.Range(10, 100), q = Random.Range(10, 100);
        while (q == p) q = Random.Range(10, 100);
        return Choice(c, "Which sign fits in the gap?", new string[] { ">", "<", "=" }, (p > q) ? 0 : 1,
            "<size=60>" + p + "   __   " + q + "</size>");
    }

    static QuestionData Class2(int kind)
    {
        ClassLevel c = ClassLevel.Class2;
        if (kind == 0)
        {
            int a = Random.Range(2, 11), b = Random.Range(2, 11);
            return Num(c, a + " \u00D7 " + b + " = ?", a * b, "");
        }
        if (kind == 1)
        {
            int b = Random.Range(2, 10), q = Random.Range(2, 10);
            return Num(c, (b * q) + " \u00F7 " + b + " = ?", q, "");
        }
        if (kind == 2)
        {
            int a = Random.Range(11, 60), b = Random.Range(11, 40);
            return Num(c, a + " + " + b + " = ?", a + b, "");
        }
        int x = Random.Range(30, 100), y = Random.Range(11, x - 9);
        return Num(c, x + " - " + y + " = ?", x - y, "");
    }

    static string Sequence(int start, int step, int hideIndex)
    {
        StringBuilder sb = new StringBuilder("<size=60>");
        for (int i = 0; i < 5; i++)
        {
            sb.Append(i == hideIndex ? "__" : (start + i * step).ToString());
            if (i < 4) sb.Append(",  ");
        }
        sb.Append("</size>");
        return sb.ToString();
    }

    // Numeric answer with 3 sensible wrong options.
    static QuestionData Num(ClassLevel c, string q, int answer, string visual)
    {
        List<int> opts = new List<int> { answer };
        int[] d = { 1, -1, 2, -2, 3, -3, 4, 5, 10, -10 };
        GameUtil.Shuffle(d);
        foreach (int x in d)
        {
            int v = answer + x;
            if (v < 0 || opts.Contains(v)) continue;
            opts.Add(v);
            if (opts.Count == 4) break;
        }
        GameUtil.Shuffle(opts);
        string[] o = new string[opts.Count];
        for (int i = 0; i < o.Length; i++) o[i] = opts[i].ToString();
        return new QuestionData
        {
            classLevel = c.ToString(), subject = "Mathematics", question = q,
            options = o, correctIndex = opts.IndexOf(answer), visual = visual
        };
    }

    static QuestionData Choice(ClassLevel c, string q, string[] opts, int correct, string visual)
    {
        return new QuestionData
        {
            classLevel = c.ToString(), subject = "Mathematics", question = q,
            options = opts, correctIndex = correct, visual = visual
        };
    }

    static QuestionData Shuffled(ClassLevel c, string q, string[] all, string correct, string visual)
    {
        string[] o = (string[])all.Clone();
        GameUtil.Shuffle(o);
        return Choice(c, q, o, System.Array.IndexOf(o, correct), visual);
    }
}
