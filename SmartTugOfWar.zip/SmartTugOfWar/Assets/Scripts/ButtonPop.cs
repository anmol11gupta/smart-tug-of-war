using UnityEngine;
using UnityEngine.EventSystems;

/// Makes UI buttons gently grow when hovered and squish when pressed.
public class ButtonPop : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    float target = 1f;
    Vector3 baseScale = Vector3.one;
    void Awake() { baseScale = transform.localScale; }
    public void OnPointerEnter(PointerEventData e) { target = 1.06f; }
    public void OnPointerExit(PointerEventData e) { target = 1f; }
    public void OnPointerDown(PointerEventData e) { target = 0.94f; }
    public void OnPointerUp(PointerEventData e) { target = 1.06f; }
    void OnDisable() { transform.localScale = baseScale; target = 1f; }
    void Update()
    {
        transform.localScale = Vector3.Lerp(transform.localScale, baseScale * target, 1f - Mathf.Exp(-14f * Time.unscaledDeltaTime));
    }
}
