using UnityEngine;

/// The rope, the centre marker and the smooth sliding. Red is on the LEFT (negative X).
public class RopeController : MonoBehaviour
{
    public float ropeHalfLength = 7f;
    public float maxOffset = 3.2f;     // how far the marker travels when a team is about to win
    public float smoothTime = 0.9f;    // bigger = slower, softer pull

    Transform ropeRoot;
    float currentX, targetX, vel;
    public bool IsMoving { get; private set; }

    public void Build(TeamController red, TeamController blue)
    {
        ropeRoot = new GameObject("RopeRoot").transform;
        ropeRoot.SetParent(transform, false);
        Color rope = GameUtil.Hex("#C9A06A"), band = GameUtil.Hex("#A87B45");

        GameObject r = GameUtil.Prim(PrimitiveType.Cylinder, ropeRoot, "Rope", new Vector3(0, 1.3f, 0), new Vector3(0.13f, ropeHalfLength, 0.13f), rope);
        r.transform.localRotation = Quaternion.Euler(0, 0, 90);
        for (int i = -6; i <= 6; i++)
        {
            GameObject b = GameUtil.Prim(PrimitiveType.Cylinder, ropeRoot, "Band", new Vector3(i * 1.0f, 1.3f, 0), new Vector3(0.16f, 0.03f, 0.16f), band);
            b.transform.localRotation = Quaternion.Euler(0, 0, 90);
        }
        GameUtil.Prim(PrimitiveType.Sphere, ropeRoot, "KnotL", new Vector3(-ropeHalfLength, 1.3f, 0), Vector3.one * 0.3f, band);
        GameUtil.Prim(PrimitiveType.Sphere, ropeRoot, "KnotR", new Vector3(ropeHalfLength, 1.3f, 0), Vector3.one * 0.3f, band);

        // Centre marker: yellow ribbon + pole + orange flag
        GameObject rib = GameUtil.Prim(PrimitiveType.Cylinder, ropeRoot, "Ribbon", new Vector3(0, 1.3f, 0), new Vector3(0.24f, 0.18f, 0.24f), GameUtil.Hex("#FFD93D"));
        rib.transform.localRotation = Quaternion.Euler(0, 0, 90);
        GameUtil.Prim(PrimitiveType.Cylinder, ropeRoot, "Pole", new Vector3(0, 1.85f, 0), new Vector3(0.05f, 0.55f, 0.05f), Color.white);
        GameUtil.Prim(PrimitiveType.Cube, ropeRoot, "Flag", new Vector3(0.3f, 2.2f, 0), new Vector3(0.55f, 0.32f, 0.03f), GameUtil.Hex("#FF8C1A"));

        red.transform.SetParent(ropeRoot, false);
        blue.transform.SetParent(ropeRoot, false);
        red.transform.localPosition = Vector3.zero;
        blue.transform.localPosition = Vector3.zero;
    }

    /// Rope moves towards whoever is ahead. Red ahead => rope slides LEFT.
    public void SetScores(int red, int blue, int winningScore)
    {
        targetX = -(red - blue) / (float)Mathf.Max(1, winningScore) * maxOffset;
    }

    void Update()
    {
        if (ropeRoot == null) return;
        currentX = Mathf.SmoothDamp(currentX, targetX, ref vel, smoothTime);
        ropeRoot.localPosition = new Vector3(currentX, 0, 0);
        IsMoving = Mathf.Abs(currentX - targetX) > 0.03f || Mathf.Abs(vel) > 0.05f;
    }
}
