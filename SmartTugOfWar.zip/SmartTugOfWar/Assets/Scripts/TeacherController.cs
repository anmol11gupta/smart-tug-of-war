using UnityEngine;
using UnityEngine.UI;

public class TeacherButtons
{
    public Button Start, Show, Reveal, Red, Blue, Skip, Next, Pause, Reset, End;
    public Text NextLabel, PauseLabel, ResetLabel, EndLabel;
}

/// Connects the teacher's keyboard + dashboard buttons to GameManager.
/// Enables/disables buttons every frame so the teacher can never click something invalid.
public class TeacherController : MonoBehaviour
{
    GameManager gm;
    TeacherButtons b;
    string pending;
    float pendingTime;

    public void Bind(GameManager manager, TeacherButtons buttons) { gm = manager; b = buttons; }

    // Reset and End need a second click within 3 seconds (prevents accidents).
    public void ClickReset()
    {
        if (!gm.CanReset) return;
        if (pending == "reset") { ClearPending(); gm.ResetMatch(); return; }
        ClearPending(); pending = "reset"; pendingTime = Time.unscaledTime;
        b.ResetLabel.text = "SURE? CLICK AGAIN";
    }

    public void ClickEnd()
    {
        if (!gm.CanEnd) return;
        if (pending == "end") { ClearPending(); gm.EndGame(); return; }
        ClearPending(); pending = "end"; pendingTime = Time.unscaledTime;
        b.EndLabel.text = "SURE? CLICK AGAIN";
    }

    void ClearPending()
    {
        pending = null;
        if (b == null) return;
        b.ResetLabel.text = "RESET MATCH";
        b.EndLabel.text = "END GAME";
    }

    void Update()
    {
        if (gm == null || b == null) return;
        b.Start.interactable = gm.CanStartRound;
        b.Show.interactable = gm.CanShowQuestion;
        b.Reveal.interactable = gm.CanReveal;
        b.Red.interactable = gm.CanAward;
        b.Blue.interactable = gm.CanAward;
        b.Skip.interactable = gm.CanSkip;
        b.Next.interactable = gm.CanNext;
        b.Pause.interactable = gm.CanPause;
        b.Reset.interactable = gm.CanReset;
        b.End.interactable = gm.CanEnd;
        b.NextLabel.text = gm.IsLastRound ? "FINISH GAME  (N)" : "NEXT ROUND  (N)";
        b.PauseLabel.text = gm.State == GameState.Paused ? "RESUME  (P)" : "PAUSE  (P)";

        if (pending != null && Time.unscaledTime - pendingTime > 3f) ClearPending();
        if (!gm.InMatch) { if (pending != null) ClearPending(); return; }

        if (Input.GetKeyDown(KeyCode.S)) gm.StartRound();
        if (Input.GetKeyDown(KeyCode.Q)) gm.ShowQuestion();
        if (Input.GetKeyDown(KeyCode.A)) gm.RevealAnswer();
        if (Input.GetKeyDown(KeyCode.R)) gm.AwardPoint(TeamSide.Red);
        if (Input.GetKeyDown(KeyCode.B)) gm.AwardPoint(TeamSide.Blue);
        if (Input.GetKeyDown(KeyCode.X)) gm.SkipQuestion();
        if (Input.GetKeyDown(KeyCode.N)) gm.NextRound();
        if (Input.GetKeyDown(KeyCode.P)) gm.TogglePause();
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (gm.CanStartRound) gm.StartRound();
            else if (gm.CanShowQuestion) gm.ShowQuestion();
            else if (gm.CanNext) gm.NextRound();
        }
    }
}
