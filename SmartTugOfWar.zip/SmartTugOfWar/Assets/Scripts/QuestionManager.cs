using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class RoundQuestions
{
    public QuestionData red, blue;
    public string subjectLabel;
}

/// Loads every JSON file in Resources/Questions and hands out two different, equal-level
/// questions per round (same class + same subject). Maths is generated automatically.
public class QuestionManager : MonoBehaviour
{
    readonly List<QuestionData> bank = new List<QuestionData>();
    readonly HashSet<QuestionData> used = new HashSet<QuestionData>();

    void Awake() { LoadBank(); }

    public void LoadBank()
    {
        bank.Clear(); used.Clear();
        TextAsset[] files = Resources.LoadAll<TextAsset>("Questions");
        foreach (TextAsset f in files)
        {
            QuestionBank qb = null;
            try { qb = JsonUtility.FromJson<QuestionBank>(f.text); }
            catch (System.Exception e) { Debug.LogWarning("Bad JSON in " + f.name + ": " + e.Message); }
            if (qb == null || qb.questions == null) continue;
            foreach (QuestionData q in qb.questions)
            {
                if (q != null && q.IsValid()) bank.Add(q);
                else Debug.LogWarning("Skipped an invalid question in " + f.name);
            }
        }
        Debug.Log("Question bank loaded: " + bank.Count + " questions");
    }

    public int CountFor(ClassLevel c, Subject s) { return Pool(c, s).Count; }

    List<QuestionData> Pool(ClassLevel c, Subject s)
    {
        string cn = c.ToString(), sn = s.ToString();
        return bank.Where(q => q.classLevel == cn && q.subject == sn).ToList();
    }

    public RoundQuestions GetRoundQuestions(ClassLevel c, Subject s)
    {
        Subject chosen = s;
        if (s == Subject.Mixed) chosen = (Subject)Random.Range(0, 4); // same subject for both teams = fair
        RoundQuestions rq = new RoundQuestions { subjectLabel = QuestionLabels.SubjectName(chosen) };
        List<QuestionData> pool = Pool(c, chosen);

        bool useJson = pool.Count >= 2 && (chosen != Subject.Mathematics || Random.value < 0.4f);
        if (useJson && TryPick(pool, out rq.red, out rq.blue)) return rq;

        if (chosen == Subject.Mathematics || pool.Count < 2)
        {
            if (chosen != Subject.Mathematics)
                Debug.LogWarning("Not enough " + chosen + " questions for " + c + " - using Maths instead.");
            rq.subjectLabel = QuestionLabels.SubjectName(Subject.Mathematics);
            int kind = Random.Range(0, MathQuestionGenerator.KindCount(c));
            rq.red = MathQuestionGenerator.Make(c, kind);
            rq.blue = MathQuestionGenerator.Make(c, kind);
            int tries = 0;
            while (Same(rq.red, rq.blue) && tries++ < 25) rq.blue = MathQuestionGenerator.Make(c, kind);
        }
        return rq;
    }

    static bool Same(QuestionData a, QuestionData b)
    {
        return a.question == b.question && a.visual == b.visual;
    }

    bool TryPick(List<QuestionData> pool, out QuestionData a, out QuestionData b)
    {
        List<QuestionData> avail = pool.Where(q => !used.Contains(q)).ToList();
        if (avail.Count < 2)
        {
            foreach (QuestionData p in pool) used.Remove(p);
            avail = new List<QuestionData>(pool);
        }
        if (avail.Count < 2) { a = null; b = null; return false; }
        int i = Random.Range(0, avail.Count);
        QuestionData qa = avail[i]; avail.RemoveAt(i);
        QuestionData qb = avail[Random.Range(0, avail.Count)];
        used.Add(qa); used.Add(qb);
        a = ShuffledCopy(qa); b = ShuffledCopy(qb);
        return true;
    }

    static QuestionData ShuffledCopy(QuestionData q)
    {
        string correct = q.options[q.correctIndex];
        string[] o = (string[])q.options.Clone();
        GameUtil.Shuffle(o);
        return new QuestionData
        {
            classLevel = q.classLevel, subject = q.subject, question = q.question, visual = q.visual,
            options = o, correctIndex = System.Array.IndexOf(o, correct)
        };
    }
}
