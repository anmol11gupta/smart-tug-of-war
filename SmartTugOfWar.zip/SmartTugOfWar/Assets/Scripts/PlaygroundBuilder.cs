using UnityEngine;

/// Builds the school playground: grass, centre line, win lines, trees, fence, hills, sun, clouds, flowers.
public class PlaygroundBuilder : MonoBehaviour
{
    public void Build(float maxOffset)
    {
        Transform root = new GameObject("Playground").transform;
        Random.State saved = Random.state;
        Random.InitState(12345);   // same decoration every time

        GameUtil.Prim(PrimitiveType.Cube, root, "Ground", new Vector3(0, -0.25f, 4), new Vector3(80, 0.5f, 44), GameUtil.Hex("#6CC24A"));
        for (int i = -6; i <= 6; i += 2)
            GameUtil.Prim(PrimitiveType.Cube, root, "Stripe", new Vector3(i * 4.5f, 0.005f, 4), new Vector3(4.5f, 0.01f, 44), GameUtil.Hex("#7FD257"));

        // Centre line + coloured win lines
        GameUtil.Prim(PrimitiveType.Cube, root, "CentreLine", new Vector3(0, 0.02f, 0.4f), new Vector3(0.18f, 0.02f, 6f), Color.white);
        GameUtil.Prim(PrimitiveType.Cube, root, "RedWinLine", new Vector3(-maxOffset, 0.02f, 0.4f), new Vector3(0.14f, 0.02f, 6f), GameUtil.Hex("#FF3B3B"));
        GameUtil.Prim(PrimitiveType.Cube, root, "BlueWinLine", new Vector3(maxOffset, 0.02f, 0.4f), new Vector3(0.14f, 0.02f, 6f), GameUtil.Hex("#2F80FF"));

        // Hills and sun
        GameUtil.Prim(PrimitiveType.Sphere, root, "Hill1", new Vector3(-18, -6, 26), new Vector3(34, 15, 12), GameUtil.Hex("#58B340"));
        GameUtil.Prim(PrimitiveType.Sphere, root, "Hill2", new Vector3(14, -8, 30), new Vector3(40, 18, 12), GameUtil.Hex("#72C957"));
        GameUtil.Prim(PrimitiveType.Sphere, root, "Sun", new Vector3(15, 12, 32), Vector3.one * 4f, GameUtil.Hex("#FFE066"));

        // Clouds
        for (int i = 0; i < 7; i++)
        {
            GameObject cloud = new GameObject("Cloud");
            cloud.transform.SetParent(root, false);
            cloud.transform.position = new Vector3(Random.Range(-30f, 30f), Random.Range(8f, 12f), Random.Range(18f, 28f));
            for (int p = 0; p < 4; p++)
                GameUtil.Prim(PrimitiveType.Sphere, cloud.transform, "Puff", new Vector3(p * 1.4f - 2f, Random.Range(-0.2f, 0.4f), 0), Vector3.one * Random.Range(1.8f, 2.8f), Color.white);
            cloud.AddComponent<CloudMover>().speed = Random.Range(0.25f, 0.6f);
        }

        // Trees
        float[] tx = { -14, 14, -9, 9, -19, 19, -4, 5 };
        float[] tz = { 7, 8, 12, 13, 10, 11, 16, 17 };
        for (int i = 0; i < tx.Length; i++)
        {
            GameObject tree = new GameObject("Tree");
            tree.transform.SetParent(root, false);
            tree.transform.position = new Vector3(tx[i], 0, tz[i]);
            GameUtil.Prim(PrimitiveType.Cylinder, tree.transform, "Trunk", new Vector3(0, 1.5f, 0), new Vector3(0.5f, 1.5f, 0.5f), GameUtil.Hex("#8B5A2B"));
            GameObject top = GameUtil.Prim(PrimitiveType.Sphere, tree.transform, "Leaves", new Vector3(0, 4.2f, 0), Vector3.one * 4f, GameUtil.Hex("#3FA34D"));
            GameUtil.Prim(PrimitiveType.Sphere, top.transform, "Leaves2", new Vector3(0.3f, 0.35f, 0), Vector3.one * 0.7f, GameUtil.Hex("#4CBB5B"));
            tree.AddComponent<Sway>().amplitude = 1.5f;
        }

        // Fence
        for (int x = -20; x <= 20; x += 2)
            GameUtil.Prim(PrimitiveType.Cube, root, "Post", new Vector3(x, 0.55f, 6), new Vector3(0.2f, 1.1f, 0.2f), GameUtil.Hex("#F5DEB3"));
        GameUtil.Prim(PrimitiveType.Cube, root, "Rail1", new Vector3(0, 0.4f, 6), new Vector3(42, 0.12f, 0.08f), GameUtil.Hex("#F5DEB3"));
        GameUtil.Prim(PrimitiveType.Cube, root, "Rail2", new Vector3(0, 0.85f, 6), new Vector3(42, 0.12f, 0.08f), GameUtil.Hex("#F5DEB3"));

        // Flowers and swaying grass tufts
        string[] flowerColours = { "#FF6B9D", "#FFD93D", "#FFFFFF", "#C77DFF", "#FF8C42" };
        for (int i = 0; i < 70; i++)
        {
            float z = Random.value < 0.5f ? Random.Range(3f, 12f) : Random.Range(-7f, -2f);
            GameUtil.Prim(PrimitiveType.Sphere, root, "Flower", new Vector3(Random.Range(-22f, 22f), 0.12f, z), Vector3.one * 0.22f, GameUtil.Hex(flowerColours[Random.Range(0, flowerColours.Length)]));
        }
        for (int i = 0; i < 90; i++)
        {
            float z = Random.value < 0.5f ? Random.Range(3f, 12f) : Random.Range(-7f, -2f);
            GameObject g = GameUtil.Prim(PrimitiveType.Cube, root, "Grass", new Vector3(Random.Range(-22f, 22f), 0.25f, z), new Vector3(0.06f, 0.5f, 0.06f), GameUtil.Hex("#4FB83A"));
            Sway s = g.AddComponent<Sway>();
            s.amplitude = 12f; s.speed = Random.Range(1.5f, 2.5f); s.phase = Random.Range(0f, 6f);
        }
        Random.state = saved;
    }
}
