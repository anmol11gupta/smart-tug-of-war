using System.Collections.Generic;
using UnityEngine;

/// Small helpers shared by many scripts.
public static class GameUtil
{
    static Material template;

    // Clones the default primitive material so it works in Built-in AND URP projects.
    public static Material NewMat(Color c)
    {
        if (template == null)
        {
            GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            template = g.GetComponent<Renderer>().sharedMaterial;
            Object.Destroy(g);
        }
        Material m = new Material(template);
        m.color = c;
        return m;
    }

    public static GameObject Prim(PrimitiveType type, Transform parent, string name, Vector3 pos, Vector3 scale, Color c)
    {
        GameObject g = GameObject.CreatePrimitive(type);
        g.name = name;
        Collider col = g.GetComponent<Collider>();
        if (col != null) Object.Destroy(col);
        g.transform.SetParent(parent, false);
        g.transform.localPosition = pos;
        g.transform.localScale = scale;
        g.GetComponent<Renderer>().material = NewMat(c);
        return g;
    }

    public static Color Hex(string h)
    {
        Color c = Color.magenta;
        ColorUtility.TryParseHtmlString(h, out c);
        return c;
    }

    public static void Shuffle<T>(IList<T> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            T tmp = list[i]; list[i] = list[j]; list[j] = tmp;
        }
    }
}
