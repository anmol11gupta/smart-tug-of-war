using System.Collections.Generic;
using UnityEngine;

/// One team of kids. Build() creates them; SetState() animates all of them.
public class TeamController : MonoBehaviour
{
    public TeamSide Side { get; private set; }
    public Color TeamColor { get; private set; }
    public readonly List<KidCharacter> Kids = new List<KidCharacter>();

    static readonly string[] Skins = { "#F5CBA7", "#E0A27A", "#C68642", "#8D5524", "#F1C27D" };
    static readonly string[] Hairs = { "#2B1B0E", "#5A3825", "#111111", "#A0522D", "#D4A017" };

    public void Build(TeamSide side, Color shirt, int count)
    {
        Side = side; TeamColor = shirt;
        int dir = side == TeamSide.Red ? -1 : 1;
        for (int i = 0; i < count; i++)
        {
            int n = i + (side == TeamSide.Red ? 0 : 2);
            KidCharacter k = KidCharacter.Create(transform, dir, shirt,
                GameUtil.Hex(Skins[n % Skins.Length]), GameUtil.Hex(Hairs[(n * 2) % Hairs.Length]), i * 0.7f + (dir > 0 ? 0.35f : 0f));
            k.transform.localPosition = new Vector3(dir * (2.4f + i * 1.3f), 0, 0.65f);
            Kids.Add(k);
        }
    }

    public void SetState(KidState s, float pullIntensity = 0.3f)
    {
        foreach (KidCharacter k in Kids) k.SetState(s, pullIntensity);
    }
}
