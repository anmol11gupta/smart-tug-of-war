using UnityEngine;

public enum KidState { Idle, Pull, Celebrate, Oops, Clap }

/// A cute placeholder cartoon kid built from primitives and animated by code (no Animator needed).
public class KidCharacter : MonoBehaviour
{
    Transform pivot, headPivot, armA, armB, legA, legB;
    int dir;            // -1 = Red kid (left, faces +X), +1 = Blue kid (right, faces -X)
    float phase;
    KidState state = KidState.Idle;
    float intensity = 0.3f;
    float lean, yOff, arm, headTilt, yaw, leg;

    public static KidCharacter Create(Transform parent, int dir, Color shirt, Color skin, Color hair, float phase)
    {
        GameObject go = new GameObject("Kid");
        go.transform.SetParent(parent, false);
        KidCharacter k = go.AddComponent<KidCharacter>();
        k.Build(dir, shirt, skin, hair, phase);
        return k;
    }

    public void SetState(KidState s, float pullIntensity) { state = s; intensity = pullIntensity; }

    void Build(int d, Color shirt, Color skin, Color hair, float ph)
    {
        dir = d; phase = ph;
        float face = -d;
        pivot = new GameObject("Pivot").transform;
        pivot.SetParent(transform, false);

        GameUtil.Prim(PrimitiveType.Capsule, pivot, "Body", new Vector3(0, 0.85f, 0), new Vector3(0.62f, 0.45f, 0.5f), shirt);
        legA = MakeLeg("LegA", 0.13f, face, skin);
        legB = MakeLeg("LegB", -0.13f, face, skin);
        armA = MakeArm("ArmA", face * 0.2f, skin);
        armB = MakeArm("ArmB", -face * 0.2f, skin);

        headPivot = new GameObject("Head").transform;
        headPivot.SetParent(pivot, false);
        headPivot.localPosition = new Vector3(0, 1.6f, 0);
        GameUtil.Prim(PrimitiveType.Sphere, headPivot, "Skull", Vector3.zero, Vector3.one * 0.8f, skin);
        for (int s = -1; s <= 1; s += 2)
        {
            GameUtil.Prim(PrimitiveType.Sphere, headPivot, "Eye", new Vector3(face * 0.33f, 0.06f, s * 0.16f), new Vector3(0.13f, 0.16f, 0.13f), Color.black);
            GameUtil.Prim(PrimitiveType.Sphere, headPivot, "Cheek", new Vector3(face * 0.34f, -0.08f, s * 0.24f), Vector3.one * 0.1f, new Color(1f, 0.6f, 0.64f));
        }
        GameUtil.Prim(PrimitiveType.Cube, headPivot, "Mouth", new Vector3(face * 0.39f, -0.13f, 0), new Vector3(0.03f, 0.05f, 0.14f), new Color(0.69f, 0.23f, 0.28f));
        GameUtil.Prim(PrimitiveType.Sphere, headPivot, "Hair", new Vector3(-face * 0.04f, 0.23f, 0), new Vector3(0.82f, 0.42f, 0.82f), hair);
    }

    Transform MakeLeg(string n, float z, float face, Color skin)
    {
        Transform p = new GameObject(n).transform;
        p.SetParent(pivot, false);
        p.localPosition = new Vector3(0, 0.5f, z);
        GameUtil.Prim(PrimitiveType.Capsule, p, "Leg", new Vector3(0, -0.22f, 0), new Vector3(0.2f, 0.22f, 0.2f), skin);
        GameUtil.Prim(PrimitiveType.Sphere, p, "Shoe", new Vector3(face * 0.06f, -0.46f, 0), new Vector3(0.32f, 0.16f, 0.22f), Color.white);
        return p;
    }

    Transform MakeArm(string n, float x, Color skin)
    {
        Transform p = new GameObject(n).transform;
        p.SetParent(pivot, false);
        p.localPosition = new Vector3(x, 1.22f, -0.2f);
        GameObject a = GameUtil.Prim(PrimitiveType.Capsule, p, "Arm", new Vector3(0, 0, -0.2f), new Vector3(0.14f, 0.2f, 0.14f), skin);
        a.transform.localRotation = Quaternion.Euler(90, 0, 0);
        GameUtil.Prim(PrimitiveType.Sphere, p, "Hand", new Vector3(0, 0, -0.42f), Vector3.one * 0.17f, skin);
        return p;
    }

    void Update()
    {
        float t = Time.time + phase;
        float tLean = 0, tY = 0, tArm = 10, tHead = 0, tYaw = 0, tLeg = 0;
        switch (state)
        {
            case KidState.Idle:
                tY = Mathf.Abs(Mathf.Sin(t * 2.5f)) * 0.08f;
                tLean = 4 + Mathf.Sin(t * 2f) * 2f;
                tArm = 15 + Mathf.Sin(t * 2.5f) * 8f;
                tHead = Mathf.Sin(t * 1.5f) * 5f;
                break;
            case KidState.Pull:
                tLean = 6 + 16 * intensity + Mathf.Sin(t * 5f) * 4f * intensity;
                tY = Mathf.Abs(Mathf.Sin(t * 5f)) * 0.04f * intensity;
                tArm = 8 + Mathf.Sin(t * 5f) * 6f * intensity;
                tLeg = Mathf.Sin(t * 5f) * 20f * intensity;
                tHead = -4;
                break;
            case KidState.Celebrate:
                tY = Mathf.Abs(Mathf.Sin(t * 6f)) * 0.55f;
                tArm = 100 + Mathf.Sin(t * 12f) * 25f;
                tYaw = Mathf.Sin(t * 4f) * 20f;
                tHead = Mathf.Sin(t * 6f) * 8f;
                tLeg = Mathf.Sin(t * 12f) * 12f;
                break;
            case KidState.Oops:
                tLean = -6 + Mathf.Sin(t * 1.5f) * 3f;
                tArm = -5;
                tHead = 14;
                tY = -0.03f;
                break;
            case KidState.Clap:
                tY = Mathf.Abs(Mathf.Sin(t * 4f)) * 0.12f;
                tArm = 45 + Mathf.Sin(t * 10f) * 15f;
                tLean = 2;
                tHead = Mathf.Sin(t * 2f) * 6f;
                break;
        }
        float k = 1f - Mathf.Exp(-7f * Time.deltaTime);   // smoothing => no sudden jumps
        lean = Mathf.Lerp(lean, tLean, k);
        yOff = Mathf.Lerp(yOff, tY, k);
        arm = Mathf.Lerp(arm, tArm, k);
        headTilt = Mathf.Lerp(headTilt, tHead, k);
        yaw = Mathf.Lerp(yaw, tYaw, k);
        leg = Mathf.Lerp(leg, tLeg, k);

        pivot.localPosition = new Vector3(0, yOff, 0);
        pivot.localRotation = Quaternion.Euler(0, yaw, -dir * lean);
        headPivot.localRotation = Quaternion.Euler(0, -dir * 35f, headTilt);
        armA.localRotation = Quaternion.Euler(arm, 0, 0);
        armB.localRotation = Quaternion.Euler(arm * 0.9f + 3f, 0, 0);
        legA.localRotation = Quaternion.Euler(0, 0, leg);
        legB.localRotation = Quaternion.Euler(0, 0, -leg);
    }
}
