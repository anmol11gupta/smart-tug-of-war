using UnityEngine;

public class CloudMover : MonoBehaviour
{
    public float speed = 0.4f;
    void Update()
    {
        transform.Translate(speed * Time.deltaTime, 0, 0, Space.World);
        if (transform.position.x > 40f)
            transform.position = new Vector3(-40f, transform.position.y, transform.position.z);
    }
}
