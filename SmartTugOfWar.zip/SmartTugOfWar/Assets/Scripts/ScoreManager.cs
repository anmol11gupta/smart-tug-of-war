using UnityEngine;

/// Only job: keep the two scores safe. No UI, no animation.
public class ScoreManager : MonoBehaviour
{
    public int RedScore { get; private set; }
    public int BlueScore { get; private set; }
    public int WinningScore { get; private set; } = 5;
    public event System.Action<int, int> OnScoreChanged;

    public bool HasWinner { get { return RedScore >= WinningScore || BlueScore >= WinningScore; } }

    public void Configure(int winningScore)
    {
        WinningScore = Mathf.Clamp(winningScore, 1, 20);
        ResetScores();
    }

    public void ResetScores()
    {
        RedScore = 0; BlueScore = 0;
        if (OnScoreChanged != null) OnScoreChanged(RedScore, BlueScore);
    }

    /// Returns false (and changes nothing) if the match is already won.
    public bool AddPoint(TeamSide side)
    {
        if (HasWinner) return false;
        if (side == TeamSide.Red) RedScore = Mathf.Min(WinningScore, RedScore + 1);
        else BlueScore = Mathf.Min(WinningScore, BlueScore + 1);
        if (OnScoreChanged != null) OnScoreChanged(RedScore, BlueScore);
        return true;
    }
}
