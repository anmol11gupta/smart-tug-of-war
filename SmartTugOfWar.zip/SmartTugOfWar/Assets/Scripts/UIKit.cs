using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

/// Tiny helpers that build uGUI objects from code (so you do not wire anything by hand).
/// Anchors are given as Vector4(xMin, yMin, xMax, yMax) with values 0..1 of the parent.
public static class UIKit
{
    static Font font;
    static Sprite round;
    public static readonly Color Dark = new Color(0.22f, 0.17f, 0.38f, 1f);

    public static Color Hex(string h) { return GameUtil.Hex(h); }
    public static Vector4 A(float x0, float y0, float x1, float y1) { return new Vector4(x0, y0, x1, y1); }

    public static Font GetFont()
    {
        if (font == null)
        {
            try { font = Font.CreateDynamicFontFromOSFont(new string[] { "Comic Sans MS", "Arial", "Verdana", "Helvetica" }, 32); } catch { }
            if (font == null) { try { font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { } }
            if (font == null) { try { font = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { } }
        }
        return font;
    }

    public static Sprite Round
    {
        get
        {
            if (round == null)
            {
                int s = 64, r = 20;
                Texture2D tex = new Texture2D(s, s, TextureFormat.RGBA32, false);
                tex.filterMode = FilterMode.Bilinear;
                for (int y = 0; y < s; y++)
                    for (int x = 0; x < s; x++)
                    {
                        float px = x + 0.5f, py = y + 0.5f;
                        float cx = Mathf.Clamp(px, r, s - r), cy = Mathf.Clamp(py, r, s - r);
                        float d = Vector2.Distance(new Vector2(px, py), new Vector2(cx, cy));
                        tex.SetPixel(x, y, new Color(1, 1, 1, Mathf.Clamp01(r - d + 0.5f)));
                    }
                tex.Apply();
                round = Sprite.Create(tex, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(r, r, r, r));
            }
            return round;
        }
    }

    public static void SetAnchors(RectTransform rt, Vector4 a)
    {
        rt.anchorMin = new Vector2(a.x, a.y);
        rt.anchorMax = new Vector2(a.z, a.w);
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
    }

    public static Canvas MakeCanvas(string name)
    {
        GameObject go = new GameObject(name, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas c = go.GetComponent<Canvas>();
        c.renderMode = RenderMode.ScreenSpaceOverlay;
        c.sortingOrder = 10;
        CanvasScaler s = go.GetComponent<CanvasScaler>();
        s.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        s.referenceResolution = new Vector2(1920, 1080);
        s.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        s.matchWidthOrHeight = 0.5f;
        return c;
    }

    public static Image Panel(Transform parent, string name, Vector4 a, Color c)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        SetAnchors(go.GetComponent<RectTransform>(), a);
        Image img = go.GetComponent<Image>();
        img.sprite = Round;
        img.type = Image.Type.Sliced;
        img.color = c;
        img.raycastTarget = false;
        return img;
    }

    public static Text Label(Transform parent, string text, int size, Color color, TextAnchor anchor, Vector4 a, bool bold = false)
    {
        GameObject go = new GameObject("Text", typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        SetAnchors(go.GetComponent<RectTransform>(), a);
        Text t = go.GetComponent<Text>();
        t.font = GetFont();
        t.text = text;
        t.fontSize = size;
        t.color = color;
        t.alignment = anchor;
        t.supportRichText = true;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Truncate;
        t.resizeTextForBestFit = true;
        t.resizeTextMinSize = Mathf.Max(12, size / 3);
        t.resizeTextMaxSize = size;
        t.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
        t.raycastTarget = false;
        return t;
    }

    public static void Outline(Text t, Color c, float d)
    {
        Outline o = t.gameObject.AddComponent<Outline>();
        o.effectColor = c;
        o.effectDistance = new Vector2(d, -d);
    }

    public static Button Btn(Transform parent, string label, Vector4 a, Color col, UnityAction onClick, int size = 40, Color? textColor = null)
    {
        Image img = Panel(parent, "Btn_" + label, a, col);
        img.raycastTarget = true;
        Shadow sh = img.gameObject.AddComponent<Shadow>();
        sh.effectColor = new Color(0, 0, 0, 0.25f);
        sh.effectDistance = new Vector2(0, -6);
        Button b = img.gameObject.AddComponent<Button>();
        b.targetGraphic = img;
        ColorBlock cb = b.colors;
        cb.normalColor = Color.white;
        cb.highlightedColor = new Color(0.93f, 0.93f, 0.93f, 1);
        cb.pressedColor = new Color(0.78f, 0.78f, 0.78f, 1);
        cb.selectedColor = Color.white;
        cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.75f);
        cb.fadeDuration = 0.08f;
        b.colors = cb;
        Label(img.transform, label, size, textColor ?? Color.white, TextAnchor.MiddleCenter, A(0.04f, 0.05f, 0.96f, 0.95f), true);
        img.gameObject.AddComponent<ButtonPop>();
        b.onClick.AddListener(() => { if (AudioManager.I != null) AudioManager.I.PlayClick(); });
        if (onClick != null) b.onClick.AddListener(onClick);
        return b;
    }

    public static InputField Input(Transform parent, string name, string placeholder, Vector4 a)
    {
        Image bg = Panel(parent, name, a, Color.white);
        bg.raycastTarget = true;
        InputField f = bg.gameObject.AddComponent<InputField>();
        Text txt = Label(bg.transform, "", 42, Dark, TextAnchor.MiddleCenter, A(0.04f, 0, 0.96f, 1), true);
        txt.resizeTextForBestFit = false;
        txt.supportRichText = false;
        Text ph = Label(bg.transform, placeholder, 38, new Color(0, 0, 0, 0.35f), TextAnchor.MiddleCenter, A(0.04f, 0, 0.96f, 1));
        ph.fontStyle = FontStyle.Italic;
        ph.resizeTextForBestFit = false;
        f.textComponent = txt;
        f.placeholder = ph;
        f.targetGraphic = bg;
        f.characterLimit = 14;
        return f;
    }
}
