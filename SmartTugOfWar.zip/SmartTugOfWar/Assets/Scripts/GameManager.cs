using System.Collections;
using UnityEngine;

public enum GameState
{
    Menu, Settings, Instructions, ClassSelect, SubjectSelect, TeamSetup,
    WaitingForRound,   // match started, teacher has not pressed START ROUND yet
    RoundReady,        // questions chosen but hidden
    QuestionShown,     // questions visible, waiting for the teacher to award a point
    Resolved,          // point given (or skipped) - only NEXT ROUND allowed
    Paused,
    Finishing,         // winning point scored, rope still sliding
    Victory
}

/// The brain: owns the game state and the rules. Contains NO UI code.
/// The UI listens to OnChanged and reads the properties below.
public class GameManager : MonoBehaviour
{
    QuestionManager questions;
    ScoreManager score;
    RopeController rope;
    TeamController red, blue;
    GameState stateBeforePause;

    public GameState State { get; private set; } = GameState.Menu;
    public ClassLevel SelectedClass { get; private set; } = ClassLevel.LKG;
    public Subject SelectedSubject { get; private set; } = Subject.Mixed;
    public string RedName { get; private set; } = "RED TEAM";
    public string BlueName { get; private set; } = "BLUE TEAM";
    public int TotalRounds { get; private set; } = 10;
    public int Round { get; private set; }
    public RoundQuestions Current { get; private set; }
    public bool AnswerRevealed { get; private set; }
    public bool RoundClosed { get; private set; }          // true once a point was given or skipped
    public TeamSide? LastScorer { get; private set; }
    public string LastResult { get; private set; } = "";
    public TeamSide? Winner { get; private set; }
    public bool IsDraw { get; private set; }
    public ScoreManager Score { get { return score; } }

    public event System.Action OnChanged;

    // ---------- what the teacher is allowed to do right now ----------
    public bool CanStartRound { get { return State == GameState.WaitingForRound; } }
    public bool CanShowQuestion { get { return State == GameState.RoundReady; } }
    public bool CanReveal { get { return (State == GameState.QuestionShown || State == GameState.Resolved) && !AnswerRevealed; } }
    public bool CanAward { get { return State == GameState.QuestionShown && !RoundClosed; } }
    public bool CanSkip { get { return (State == GameState.QuestionShown || State == GameState.RoundReady) && !RoundClosed; } }
    public bool CanNext { get { return State == GameState.Resolved; } }
    public bool CanPause { get { return State == GameState.Paused || IsRoundState(State); } }
    public bool CanReset { get { return IsRoundState(State); } }
    public bool CanEnd { get { return IsRoundState(State); } }
    public bool IsLastRound { get { return Round >= TotalRounds; } }
    public bool InMatch { get { return State == GameState.Paused || State == GameState.Finishing || IsRoundState(State); } }

    static bool IsRoundState(GameState s)
    {
        return s == GameState.WaitingForRound || s == GameState.RoundReady || s == GameState.QuestionShown || s == GameState.Resolved;
    }

    public void Init(QuestionManager q, ScoreManager s, RopeController r, TeamController redTeam, TeamController blueTeam)
    {
        questions = q; score = s; rope = r; red = redTeam; blue = blueTeam;
    }

    public void Begin() { GoToMenu(); }

    void SetState(GameState s) { State = s; Changed(); }
    void Changed() { if (OnChanged != null) OnChanged(); }

    // ---------- menus ----------
    public void GoToMenu()
    {
        StopAllCoroutines();
        score.Configure(5);
        Round = 0; Current = null; Winner = null; IsDraw = false; LastScorer = null; LastResult = "";
        rope.SetScores(0, 0, 5);
        red.SetState(KidState.Idle); blue.SetState(KidState.Idle);
        SetState(GameState.Menu);
    }
    public void OpenSettings() { SetState(GameState.Settings); }
    public void OpenInstructions() { SetState(GameState.Instructions); }
    public void OpenClassSelect() { SetState(GameState.ClassSelect); }
    public void SelectClass(ClassLevel c) { SelectedClass = c; SetState(GameState.SubjectSelect); }
    public void SelectSubject(Subject s) { SelectedSubject = s; SetState(GameState.TeamSetup); }

    public void Back()
    {
        switch (State)
        {
            case GameState.Settings:
            case GameState.Instructions:
            case GameState.ClassSelect: SetState(GameState.Menu); break;
            case GameState.SubjectSelect: SetState(GameState.ClassSelect); break;
            case GameState.TeamSetup: SetState(GameState.SubjectSelect); break;
        }
    }

    // ---------- match ----------
    public void StartMatch(string redName, string blueName, int rounds, int winScore)
    {
        if (State != GameState.TeamSetup) return;
        RedName = Clean(redName, "RED TEAM");
        BlueName = Clean(blueName, "BLUE TEAM");
        TotalRounds = Mathf.Clamp(rounds, 1, 99);
        score.Configure(winScore);
        PrepareFreshMatch();
        SetState(GameState.WaitingForRound);
    }

    static string Clean(string s, string fallback)
    {
        if (string.IsNullOrEmpty(s)) return fallback;
        s = s.Trim();
        return s.Length == 0 ? fallback : s.ToUpper();
    }

    void PrepareFreshMatch()
    {
        StopAllCoroutines();
        score.ResetScores();
        Round = 0; Current = null; AnswerRevealed = false; RoundClosed = false;
        LastScorer = null; LastResult = ""; Winner = null; IsDraw = false;
        rope.SetScores(0, 0, score.WinningScore);
        SetPullReady();
    }

    void SetPullReady() { red.SetState(KidState.Pull, 0.25f); blue.SetState(KidState.Pull, 0.25f); }

    // ---------- teacher actions ----------
    public void StartRound()
    {
        if (!CanStartRound) return;
        BeginRound();
    }

    void BeginRound()
    {
        Round++;
        Current = questions.GetRoundQuestions(SelectedClass, SelectedSubject);
        AnswerRevealed = false; RoundClosed = false; LastScorer = null; LastResult = "";
        SetState(GameState.RoundReady);
    }

    public void ShowQuestion() { if (CanShowQuestion) SetState(GameState.QuestionShown); }

    public void RevealAnswer() { if (!CanReveal) return; AnswerRevealed = true; Changed(); }

    public void AwardPoint(TeamSide side)
    {
        if (!CanAward) return;          // guard 1: wrong state or already scored
        RoundClosed = true;             // guard 2: lock BEFORE doing anything else (no double scoring)
        if (!score.AddPoint(side)) return;
        LastScorer = side;
        LastResult = (side == TeamSide.Red ? RedName : BlueName) + "\nGETS A POINT!";
        if (AudioManager.I != null) AudioManager.I.PlayCorrect();
        rope.SetScores(score.RedScore, score.BlueScore, score.WinningScore);

        if (score.HasWinner)
        {
            SetState(GameState.Finishing);
            StartCoroutine(WinSequence(side));
        }
        else
        {
            SetState(GameState.Resolved);
            StartCoroutine(PointReaction(side));
        }
    }

    public void SkipQuestion()
    {
        if (!CanSkip) return;
        RoundClosed = true;
        LastScorer = null;
        LastResult = "NO POINT THIS ROUND\nGood try, everyone!";
        if (AudioManager.I != null) AudioManager.I.PlayWrong();
        SetState(GameState.Resolved);
        StartCoroutine(SkipReaction());
    }

    public void NextRound()
    {
        if (!CanNext) return;
        if (IsLastRound) { FinishMatch(); return; }
        BeginRound();
    }

    public void TogglePause()
    {
        if (State == GameState.Paused) SetState(stateBeforePause);
        else if (CanPause) { stateBeforePause = State; SetState(GameState.Paused); }
    }

    public void ResetMatch()
    {
        if (!CanReset && State != GameState.Victory) return;
        PrepareFreshMatch();
        SetState(GameState.WaitingForRound);
    }

    public void EndGame() { if (CanEnd) FinishMatch(); }
    public void PlayAgain() { if (State == GameState.Victory) ResetMatch(); }

    // ---------- reactions (animation timing only) ----------
    IEnumerator PointReaction(TeamSide side)
    {
        TeamController win = side == TeamSide.Red ? red : blue;
        TeamController lose = side == TeamSide.Red ? blue : red;
        win.SetState(KidState.Pull, 1f);
        lose.SetState(KidState.Pull, 0.6f);
        if (AudioManager.I != null) AudioManager.I.PlayRope();
        yield return new WaitForSeconds(0.15f);
        while (rope.IsMoving) yield return null;
        win.SetState(KidState.Celebrate);
        lose.SetState(KidState.Oops);
        yield return new WaitForSeconds(1.8f);
        SetPullReady();
    }

    IEnumerator SkipReaction()
    {
        red.SetState(KidState.Oops); blue.SetState(KidState.Oops);
        yield return new WaitForSeconds(1.2f);
        SetPullReady();
    }

    IEnumerator WinSequence(TeamSide side)
    {
        TeamController win = side == TeamSide.Red ? red : blue;
        TeamController lose = side == TeamSide.Red ? blue : red;
        win.SetState(KidState.Pull, 1f);
        lose.SetState(KidState.Pull, 0.6f);
        if (AudioManager.I != null) AudioManager.I.PlayRope();
        yield return new WaitForSeconds(0.15f);
        while (rope.IsMoving) yield return null;
        yield return new WaitForSeconds(0.8f);
        FinishMatch();
    }

    void FinishMatch()
    {
        StopAllCoroutines();
        IsDraw = score.RedScore == score.BlueScore;
        if (!IsDraw) Winner = score.RedScore > score.BlueScore ? TeamSide.Red : TeamSide.Blue;
        if (IsDraw) { red.SetState(KidState.Celebrate); blue.SetState(KidState.Celebrate); }
        else
        {
            TeamController win = Winner == TeamSide.Red ? red : blue;
            TeamController lose = Winner == TeamSide.Red ? blue : red;
            win.SetState(KidState.Celebrate);
            lose.SetState(KidState.Clap);   // friendly: the other team claps for the winners
        }
        if (AudioManager.I != null) AudioManager.I.PlayVictory();
        SetState(GameState.Victory);
    }
}
