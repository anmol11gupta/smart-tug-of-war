using UnityEngine;
using UnityEngine.EventSystems;

/// THE ONLY SCRIPT YOU ATTACH BY HAND. Put it on one empty GameObject in an empty scene.
/// On Play it creates the camera rig, playground, kids, rope, UI and all managers.
public class GameBootstrap : MonoBehaviour
{
    [Header("Gameplay look (safe to tweak)")]
    public int kidsPerTeam = 4;
    public float ropeMaxOffset = 3.2f;
    public Vector3 cameraPosition = new Vector3(0f, 3.4f, -16f);
    public Vector3 cameraLookAt = new Vector3(0f, 3.0f, 0f);

    void Awake()
    {
        Application.targetFrameRate = 60;
        SetupCamera();
        SetupLights();
        if (EventSystem.current == null)
        {
            GameObject es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        }

        AudioManager audio = gameObject.AddComponent<AudioManager>();
        QuestionManager qm = gameObject.AddComponent<QuestionManager>();
        ScoreManager sm = gameObject.AddComponent<ScoreManager>();
        gameObject.AddComponent<PlaygroundBuilder>().Build(ropeMaxOffset);

        TeamController red = new GameObject("RedTeam").AddComponent<TeamController>();
        red.Build(TeamSide.Red, GameUtil.Hex("#FF3B3B"), kidsPerTeam);
        TeamController blue = new GameObject("BlueTeam").AddComponent<TeamController>();
        blue.Build(TeamSide.Blue, GameUtil.Hex("#2F80FF"), kidsPerTeam);

        RopeController rope = gameObject.AddComponent<RopeController>();
        rope.maxOffset = ropeMaxOffset;
        rope.Build(red, blue);

        GameManager gm = gameObject.AddComponent<GameManager>();
        gm.Init(qm, sm, rope, red, blue);
        // Rope follows the score automatically.
        sm.OnScoreChanged += (r, b) => rope.SetScores(r, b, sm.WinningScore);

        TeacherController teacher = gameObject.AddComponent<TeacherController>();
        UIManager ui = gameObject.AddComponent<UIManager>();
        ui.Build(gm, teacher);
        gm.Begin();
    }

    void SetupCamera()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject go = new GameObject("Main Camera");
            go.tag = "MainCamera";
            cam = go.AddComponent<Camera>();
            go.AddComponent<AudioListener>();
        }
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = GameUtil.Hex("#87CEEB");
        cam.fieldOfView = 45f;
        cam.transform.position = cameraPosition;
        cam.transform.rotation = Quaternion.LookRotation(cameraLookAt - cameraPosition);
    }

    void SetupLights()
    {
#if UNITY_2023_1_OR_NEWER
        Light[] old = FindObjectsByType<Light>(FindObjectsSortMode.None);
#else
        Light[] old = FindObjectsOfType<Light>();
#endif
        foreach (Light l in old) l.enabled = false;
        GameObject go = new GameObject("Sun Light");
        Light light = go.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        light.shadows = LightShadows.Soft;
        go.transform.rotation = Quaternion.Euler(50f, -25f, 0f);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.72f, 0.74f, 0.8f);
    }
}
