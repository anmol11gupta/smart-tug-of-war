using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// Builds every screen from code and shows/hides them according to GameManager.State.
/// Contains NO game rules - it only displays what GameManager says and forwards clicks.
public class UIManager : MonoBehaviour
{
    class UIScreen { public CanvasGroup group; public RectTransform rt; public float target; }
    class QPanel
    {
        public RectTransform root; public Text header, question, visual;
        public Image[] optBg = new Image[4]; public Text[] opt = new Text[4];
    }
    class Piece { public RectTransform rt; public float vx, vy, rot, rotSpeed; }

    static readonly Color Red = new Color(1f, 0.23f, 0.23f), Blue = new Color(0.18f, 0.5f, 1f);

    GameManager gm;
    Transform cRoot;
    readonly Dictionary<string, UIScreen> screens = new Dictionary<string, UIScreen>();
    readonly List<System.Action> volumeRefresh = new List<System.Action>();

    RectTransform titleRt;
    Text subjectSub;
    InputField redInput, blueInput;
    int rounds = 10, winScore = 5;
    Text roundsValue, winValue;

    Text redNameT, redScoreT, blueNameT, blueScoreT, roundT, infoT, hintT, bannerT;
    Image bannerBg;
    QPanel redQ, blueQ;
    float redPop, bluePop; int lastRed, lastBlue;

    Text winHeader, winNameT, winScoreT, winMsgT;
    RectTransform trophyRt, confettiRoot;
    readonly List<Piece> confetti = new List<Piece>();
    GameState prevState = GameState.Menu;

    // ====================================================== build
    public void Build(GameManager manager, TeacherController teacher)
    {
        gm = manager;
        Canvas canvas = UIKit.MakeCanvas("UI");
        cRoot = canvas.transform;
        BuildMenu(); BuildClassSelect(); BuildSubjectSelect(); BuildTeamSetup();
        BuildSettings(); BuildInstructions(); BuildHud(teacher); BuildPause(); BuildVictory();
        gm.OnChanged += Refresh;
        Refresh();
    }

    RectTransform NewScreen(string key)
    {
        GameObject go = new GameObject(key, typeof(RectTransform), typeof(CanvasGroup));
        go.transform.SetParent(cRoot, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        UIKit.SetAnchors(rt, UIKit.A(0, 0, 1, 1));
        CanvasGroup cg = go.GetComponent<CanvasGroup>();
        cg.alpha = 0f;
        screens[key] = new UIScreen { group = cg, rt = rt, target = 0f };
        return rt;
    }

    Image Dim(RectTransform parent, float alpha)
    {
        Image d = UIKit.Panel(parent, "Dim", UIKit.A(0, 0, 1, 1), new Color(0.1f, 0.1f, 0.25f, alpha));
        d.raycastTarget = true;
        return d;
    }

    Text Title(Transform parent, string s, Vector4 a)
    {
        Text t = UIKit.Label(parent, s, 90, UIKit.Hex("#FFD93D"), TextAnchor.MiddleCenter, a, true);
        UIKit.Outline(t, UIKit.Hex("#E8590C"), 4);
        return t;
    }

    void BuildMenu()
    {
        RectTransform m = NewScreen("menu");
        Text title = UIKit.Label(m, "SMART TUG OF WAR", 130, UIKit.Hex("#FFD93D"), TextAnchor.MiddleCenter, UIKit.A(0.08f, 0.64f, 0.92f, 0.97f), true);
        UIKit.Outline(title, UIKit.Hex("#E8590C"), 6);
        titleRt = title.rectTransform;
        Text sub = UIKit.Label(m, "Learn  \u2022  Play  \u2022  Win!", 52, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.3f, 0.56f, 0.7f, 0.64f), true);
        UIKit.Outline(sub, UIKit.Hex("#3B82F6"), 3);
        UIKit.Btn(m, "PLAY", UIKit.A(0.36f, 0.40f, 0.64f, 0.54f), UIKit.Hex("#51CF66"), () => gm.OpenClassSelect(), 80);
        UIKit.Btn(m, "SETTINGS", UIKit.A(0.38f, 0.27f, 0.62f, 0.37f), UIKit.Hex("#FF9F1C"), () => gm.OpenSettings(), 46);
        UIKit.Btn(m, "INSTRUCTIONS", UIKit.A(0.38f, 0.15f, 0.62f, 0.25f), UIKit.Hex("#4DABF7"), () => gm.OpenInstructions(), 46);
        UIKit.Btn(m, "QUIT", UIKit.A(0.9f, 0.03f, 0.98f, 0.09f), UIKit.Hex("#FF8FAB"), () =>
        {
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }, 30);
    }

    void BackButton(RectTransform parent, Vector4 a)
    {
        UIKit.Btn(parent, "BACK", a, UIKit.Hex("#FF8FAB"), () => gm.Back(), 40);
    }

    void BuildClassSelect()
    {
        RectTransform s = NewScreen("class");
        Dim(s, 0.25f);
        Title(s, "CHOOSE YOUR CLASS", UIKit.A(0.1f, 0.74f, 0.9f, 0.95f));
        string[] names = { "LKG", "UKG", "CLASS 1", "CLASS 2" };
        string[] cols = { "#FF8FAB", "#38D9A9", "#4DABF7", "#FFB020" };
        ClassLevel[] lv = { ClassLevel.LKG, ClassLevel.UKG, ClassLevel.Class1, ClassLevel.Class2 };
        for (int i = 0; i < 4; i++)
        {
            ClassLevel c = lv[i];
            float x0 = 0.05f + i * 0.2375f;
            UIKit.Btn(s, names[i], UIKit.A(x0, 0.34f, x0 + 0.215f, 0.66f), UIKit.Hex(cols[i]), () => gm.SelectClass(c), 70);
        }
        BackButton(s, UIKit.A(0.03f, 0.04f, 0.18f, 0.12f));
    }

    void BuildSubjectSelect()
    {
        RectTransform s = NewScreen("subject");
        Dim(s, 0.25f);
        Title(s, "CHOOSE A SUBJECT", UIKit.A(0.1f, 0.74f, 0.9f, 0.95f));
        subjectSub = UIKit.Label(s, "", 46, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.3f, 0.66f, 0.7f, 0.74f), true);
        UIKit.Outline(subjectSub, UIKit.Dark, 3);
        string[] names = { "MATHS", "ENGLISH", "EVS", "GENERAL KNOWLEDGE", "MIXED MODE" };
        string[] cols = { "#FF6B6B", "#4DABF7", "#51CF66", "#FFB020", "#B197FC" };
        Subject[] sj = { Subject.Mathematics, Subject.English, Subject.EVS, Subject.GeneralKnowledge, Subject.Mixed };
        for (int i = 0; i < 5; i++)
        {
            Subject v = sj[i];
            float x0 = 0.03f + i * 0.1927f;
            UIKit.Btn(s, names[i], UIKit.A(x0, 0.30f, x0 + 0.175f, 0.60f), UIKit.Hex(cols[i]), () => gm.SelectSubject(v), 46);
        }
        BackButton(s, UIKit.A(0.03f, 0.04f, 0.18f, 0.12f));
    }

    void BuildTeamSetup()
    {
        RectTransform s = NewScreen("setup");
        Dim(s, 0.25f);
        Image p = UIKit.Panel(s, "Panel", UIKit.A(0.12f, 0.1f, 0.88f, 0.92f), UIKit.Hex("#FFF4D6"));
        Text t = UIKit.Label(p.transform, "TEAM SETUP", 80, UIKit.Hex("#FF9F1C"), TextAnchor.MiddleCenter, UIKit.A(0.1f, 0.84f, 0.9f, 0.98f), true);
        UIKit.Outline(t, Color.white, 3);

        UIKit.Label(p.transform, "RED TEAM NAME", 40, Red, TextAnchor.MiddleCenter, UIKit.A(0.05f, 0.72f, 0.48f, 0.82f), true);
        redInput = UIKit.Input(p.transform, "RedInput", "RED TEAM", UIKit.A(0.05f, 0.58f, 0.48f, 0.72f));
        UIKit.Label(p.transform, "BLUE TEAM NAME", 40, Blue, TextAnchor.MiddleCenter, UIKit.A(0.52f, 0.72f, 0.95f, 0.82f), true);
        blueInput = UIKit.Input(p.transform, "BlueInput", "BLUE TEAM", UIKit.A(0.52f, 0.58f, 0.95f, 0.72f));

        UIKit.Label(p.transform, "NUMBER OF ROUNDS", 38, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.05f, 0.46f, 0.48f, 0.56f), true);
        UIKit.Btn(p.transform, "-", UIKit.A(0.05f, 0.31f, 0.16f, 0.45f), UIKit.Hex("#FF8FAB"), () => { rounds = Mathf.Max(1, rounds - 1); roundsValue.text = rounds.ToString(); }, 70);
        roundsValue = UIKit.Label(p.transform, rounds.ToString(), 70, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.16f, 0.31f, 0.37f, 0.45f), true);
        UIKit.Btn(p.transform, "+", UIKit.A(0.37f, 0.31f, 0.48f, 0.45f), UIKit.Hex("#51CF66"), () => { rounds = Mathf.Min(30, rounds + 1); roundsValue.text = rounds.ToString(); }, 70);

        UIKit.Label(p.transform, "WINNING SCORE", 38, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.52f, 0.46f, 0.95f, 0.56f), true);
        UIKit.Btn(p.transform, "-", UIKit.A(0.52f, 0.31f, 0.63f, 0.45f), UIKit.Hex("#FF8FAB"), () => { winScore = Mathf.Max(1, winScore - 1); winValue.text = winScore.ToString(); }, 70);
        winValue = UIKit.Label(p.transform, winScore.ToString(), 70, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.63f, 0.31f, 0.84f, 0.45f), true);
        UIKit.Btn(p.transform, "+", UIKit.A(0.84f, 0.31f, 0.95f, 0.45f), UIKit.Hex("#51CF66"), () => { winScore = Mathf.Min(15, winScore + 1); winValue.text = winScore.ToString(); }, 70);

        UIKit.Btn(p.transform, "START MATCH", UIKit.A(0.3f, 0.07f, 0.74f, 0.25f), UIKit.Hex("#51CF66"),
            () => gm.StartMatch(redInput.text, blueInput.text, rounds, winScore), 64);
        BackButton((RectTransform)p.transform, UIKit.A(0.04f, 0.07f, 0.2f, 0.19f));
    }

    void VolumeRow(Transform parent, string label, float y0, float y1, bool music)
    {
        UIKit.Label(parent, label, 44, UIKit.Dark, TextAnchor.MiddleLeft, UIKit.A(0.08f, y0, 0.36f, y1), true);
        Text val = UIKit.Label(parent, "", 50, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.5f, y0, 0.66f, y1), true);
        UIKit.Btn(parent, "-", UIKit.A(0.38f, y0, 0.49f, y1), UIKit.Hex("#FF8FAB"), () => ChangeVol(music, -0.1f), 60);
        UIKit.Btn(parent, "+", UIKit.A(0.67f, y0, 0.78f, y1), UIKit.Hex("#51CF66"), () => ChangeVol(music, 0.1f), 60);
        volumeRefresh.Add(() =>
        {
            AudioManager a = AudioManager.I;
            if (a != null) val.text = Mathf.RoundToInt((music ? a.MusicVolume : a.SfxVolume) * 100f) + "%";
        });
    }

    void ChangeVol(bool music, float d)
    {
        AudioManager a = AudioManager.I;
        if (a == null) return;
        if (music) a.SetMusicVolume(a.MusicVolume + d); else a.SetSfxVolume(a.SfxVolume + d);
        foreach (System.Action r in volumeRefresh) r();
    }

    void BuildVolumeControls(Transform parent, float top)
    {
        VolumeRow(parent, "MUSIC", top - 0.2f, top, true);
        VolumeRow(parent, "SOUNDS", top - 0.4f, top - 0.2f, false);
        Text muteLabel = null;
        Button mute = UIKit.Btn(parent, "SOUND: ON", UIKit.A(0.25f, top - 0.62f, 0.75f, top - 0.44f), UIKit.Hex("#FFB020"), () =>
        {
            if (AudioManager.I != null) AudioManager.I.SetMuted(!AudioManager.I.Muted);
            foreach (System.Action r in volumeRefresh) r();
        }, 44);
        muteLabel = mute.GetComponentInChildren<Text>();
        volumeRefresh.Add(() =>
        {
            if (AudioManager.I != null) muteLabel.text = AudioManager.I.Muted ? "SOUND: OFF (MUTED)" : "SOUND: ON";
        });
    }

    void BuildSettings()
    {
        RectTransform s = NewScreen("settings");
        Dim(s, 0.3f);
        Image p = UIKit.Panel(s, "Panel", UIKit.A(0.25f, 0.12f, 0.75f, 0.9f), UIKit.Hex("#FFF4D6"));
        Text t = UIKit.Label(p.transform, "SETTINGS", 80, UIKit.Hex("#FF9F1C"), TextAnchor.MiddleCenter, UIKit.A(0.1f, 0.84f, 0.9f, 0.98f), true);
        UIKit.Outline(t, Color.white, 3);
        BuildVolumeControls(p.transform, 0.8f);
        BackButton((RectTransform)p.transform, UIKit.A(0.35f, 0.04f, 0.65f, 0.16f));
    }

    void BuildInstructions()
    {
        RectTransform s = NewScreen("instructions");
        Dim(s, 0.3f);
        Image p = UIKit.Panel(s, "Panel", UIKit.A(0.1f, 0.06f, 0.9f, 0.94f), UIKit.Hex("#FFF4D6"));
        Text t = UIKit.Label(p.transform, "HOW TO PLAY", 76, UIKit.Hex("#FF9F1C"), TextAnchor.MiddleCenter, UIKit.A(0.1f, 0.88f, 0.9f, 0.99f), true);
        UIKit.Outline(t, Color.white, 3);
        string body =
            "1.  Press PLAY, then choose a CLASS and a SUBJECT.\n" +
            "2.  Name the two teams, choose the rounds and the winning score.\n" +
            "3.  Press START ROUND, then SHOW QUESTION.\n" +
            "4.  Read both questions aloud. Children answer out loud.\n" +
            "5.  Click RED CORRECT or BLUE CORRECT for the team that answered first.\n" +
            "6.  The rope moves! Press NEXT ROUND.\n" +
            "7.  The first team to reach the winning score wins!\n\n" +
            "Keys:  S start   Q show   A answer   R red   B blue   X skip   N next   P pause   Space = next step";
        UIKit.Label(p.transform, body, 40, UIKit.Dark, TextAnchor.MiddleLeft, UIKit.A(0.05f, 0.17f, 0.95f, 0.87f));
        BackButton((RectTransform)p.transform, UIKit.A(0.38f, 0.03f, 0.62f, 0.14f));
    }

    QPanel BuildQPanel(Transform parent, Vector4 a, Color tint)
    {
        QPanel q = new QPanel();
        Image bg = UIKit.Panel(parent, "QPanel", a, new Color(1f, 1f, 1f, 0.96f));
        q.root = bg.rectTransform;
        Image strip = UIKit.Panel(q.root, "Strip", UIKit.A(0, 0.88f, 1, 1), tint);
        q.header = UIKit.Label(strip.transform, "", 42, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.02f, 0, 0.98f, 1), true);
        q.question = UIKit.Label(q.root, "", 46, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0.6f, 0.96f, 0.87f), true);
        q.visual = UIKit.Label(q.root, "", 60, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0.43f, 0.96f, 0.6f), true);
        string[] pastel = { "#FFF3BF", "#D0EBFF", "#FFD8E8", "#D3F9D8" };
        for (int i = 0; i < 4; i++)
        {
            int col = i % 2, row = i / 2;
            float x0 = 0.03f + col * 0.485f, y1 = 0.4f - row * 0.205f;
            q.optBg[i] = UIKit.Panel(q.root, "Opt" + i, UIKit.A(x0, y1 - 0.185f, x0 + 0.455f, y1), UIKit.Hex(pastel[i]));
            q.opt[i] = UIKit.Label(q.optBg[i].transform, "", 38, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0, 0.96f, 1), true);
        }
        return q;
    }

    void BuildHud(TeacherController teacher)
    {
        RectTransform h = NewScreen("hud");

        Image rb = UIKit.Panel(h, "RedBoard", UIKit.A(0.02f, 0.855f, 0.25f, 0.985f), Red);
        redNameT = UIKit.Label(rb.transform, "RED TEAM", 36, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0.58f, 0.96f, 0.98f), true);
        redScoreT = UIKit.Label(rb.transform, "0", 80, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0, 0.96f, 0.62f), true);
        Image bb = UIKit.Panel(h, "BlueBoard", UIKit.A(0.75f, 0.855f, 0.98f, 0.985f), Blue);
        blueNameT = UIKit.Label(bb.transform, "BLUE TEAM", 36, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0.58f, 0.96f, 0.98f), true);
        blueScoreT = UIKit.Label(bb.transform, "0", 80, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0, 0.96f, 0.62f), true);

        Image rp = UIKit.Panel(h, "RoundPanel", UIKit.A(0.355f, 0.865f, 0.645f, 0.985f), UIKit.Hex("#FFD93D"));
        roundT = UIKit.Label(rp.transform, "", 54, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.03f, 0.45f, 0.97f, 0.98f), true);
        infoT = UIKit.Label(rp.transform, "", 28, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.03f, 0.04f, 0.97f, 0.48f), true);

        redQ = BuildQPanel(h, UIKit.A(0.02f, 0.46f, 0.37f, 0.85f), Red);
        blueQ = BuildQPanel(h, UIKit.A(0.63f, 0.46f, 0.98f, 0.85f), Blue);

        bannerBg = UIKit.Panel(h, "Banner", UIKit.A(0.385f, 0.5f, 0.615f, 0.68f), UIKit.Hex("#FF9F1C"));
        bannerT = UIKit.Label(bannerBg.transform, "", 44, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0.04f, 0.96f, 0.96f), true);

        Image hint = UIKit.Panel(h, "Hint", UIKit.A(0.2f, 0.2f, 0.8f, 0.26f), new Color(0.15f, 0.1f, 0.3f, 0.7f));
        hintT = UIKit.Label(hint.transform, "", 32, Color.white, TextAnchor.MiddleCenter, UIKit.A(0.02f, 0, 0.98f, 1), true);

        Image bar = UIKit.Panel(h, "TeacherBar", UIKit.A(0, 0, 1, 0.19f), new Color(0.2f, 0.15f, 0.35f, 0.9f));
        Transform bt = bar.transform;
        TeacherButtons tb = new TeacherButtons();
        float w = 0.19f, gap = 0.0083f;
        System.Func<int, Vector4> r1 = i => UIKit.A(gap + i * (w + gap), 0.54f, gap + i * (w + gap) + w, 0.93f);
        System.Func<int, Vector4> r2 = i => UIKit.A(gap + i * (w + gap), 0.07f, gap + i * (w + gap) + w, 0.46f);
        tb.Start = UIKit.Btn(bt, "START ROUND  (S)", r1(0), UIKit.Hex("#51CF66"), () => gm.StartRound(), 32);
        tb.Show = UIKit.Btn(bt, "SHOW QUESTION  (Q)", r1(1), UIKit.Hex("#4DABF7"), () => gm.ShowQuestion(), 32);
        tb.Reveal = UIKit.Btn(bt, "REVEAL ANSWER  (A)", r1(2), UIKit.Hex("#FF922B"), () => gm.RevealAnswer(), 32);
        tb.Next = UIKit.Btn(bt, "NEXT ROUND  (N)", r1(3), UIKit.Hex("#20C997"), () => gm.NextRound(), 32);
        tb.Pause = UIKit.Btn(bt, "PAUSE  (P)", r1(4), UIKit.Hex("#FFD43B"), () => gm.TogglePause(), 32, UIKit.Dark);
        tb.Red = UIKit.Btn(bt, "RED CORRECT  (R)", r2(0), Red, () => gm.AwardPoint(TeamSide.Red), 34);
        tb.Blue = UIKit.Btn(bt, "BLUE CORRECT  (B)", r2(1), Blue, () => gm.AwardPoint(TeamSide.Blue), 34);
        tb.Skip = UIKit.Btn(bt, "NO POINT / SKIP  (X)", r2(2), UIKit.Hex("#9775FA"), () => gm.SkipQuestion(), 32);
        tb.Reset = UIKit.Btn(bt, "RESET MATCH", r2(3), UIKit.Hex("#F783AC"), () => teacher.ClickReset(), 32);
        tb.End = UIKit.Btn(bt, "END GAME", r2(4), UIKit.Hex("#868E96"), () => teacher.ClickEnd(), 32);
        tb.NextLabel = tb.Next.GetComponentInChildren<Text>();
        tb.PauseLabel = tb.Pause.GetComponentInChildren<Text>();
        tb.ResetLabel = tb.Reset.GetComponentInChildren<Text>();
        tb.EndLabel = tb.End.GetComponentInChildren<Text>();
        teacher.Bind(gm, tb);
    }

    void BuildPause()
    {
        RectTransform s = NewScreen("pause");
        Dim(s, 0.75f);
        Image p = UIKit.Panel(s, "Panel", UIKit.A(0.28f, 0.1f, 0.72f, 0.9f), UIKit.Hex("#FFF4D6"));
        Text t = UIKit.Label(p.transform, "PAUSED", 90, UIKit.Hex("#FF9F1C"), TextAnchor.MiddleCenter, UIKit.A(0.1f, 0.82f, 0.9f, 0.98f), true);
        UIKit.Outline(t, Color.white, 3);
        BuildVolumeControls(p.transform, 0.8f);
        UIKit.Btn(p.transform, "RESUME", UIKit.A(0.2f, 0.04f, 0.8f, 0.2f), UIKit.Hex("#51CF66"), () => gm.TogglePause(), 60);
    }

    void BuildVictory()
    {
        RectTransform s = NewScreen("victory");
        Dim(s, 0.45f);
        Image p = UIKit.Panel(s, "Panel", UIKit.A(0.2f, 0.05f, 0.8f, 0.95f), UIKit.Hex("#FFF4D6"));
        winHeader = UIKit.Label(p.transform, "WINNER!", 90, UIKit.Hex("#FFB020"), TextAnchor.MiddleCenter, UIKit.A(0.05f, 0.86f, 0.95f, 0.99f), true);
        UIKit.Outline(winHeader, Color.white, 4);

        GameObject tg = new GameObject("Trophy", typeof(RectTransform));
        tg.transform.SetParent(p.transform, false);
        trophyRt = tg.GetComponent<RectTransform>();
        UIKit.SetAnchors(trophyRt, UIKit.A(0.39f, 0.5f, 0.61f, 0.85f));
        Color gold = UIKit.Hex("#FFC107"), darkGold = UIKit.Hex("#E0A100");
        UIKit.Panel(trophyRt, "HandleL", UIKit.A(0f, 0.55f, 0.22f, 0.88f), darkGold);
        UIKit.Panel(trophyRt, "HandleR", UIKit.A(0.78f, 0.55f, 1f, 0.88f), darkGold);
        UIKit.Panel(trophyRt, "Stem", UIKit.A(0.42f, 0.12f, 0.58f, 0.38f), darkGold);
        UIKit.Panel(trophyRt, "Base", UIKit.A(0.2f, 0f, 0.8f, 0.16f), UIKit.Hex("#8D6E63"));
        Image cup = UIKit.Panel(trophyRt, "Cup", UIKit.A(0.18f, 0.32f, 0.82f, 1f), gold);
        UIKit.Label(cup.transform, "1", 110, Color.white, TextAnchor.MiddleCenter, UIKit.A(0, 0.1f, 1, 0.95f), true);

        winNameT = UIKit.Label(p.transform, "", 78, Red, TextAnchor.MiddleCenter, UIKit.A(0.04f, 0.38f, 0.96f, 0.5f), true);
        UIKit.Outline(winNameT, Color.white, 2);
        winScoreT = UIKit.Label(p.transform, "", 48, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.05f, 0.3f, 0.95f, 0.38f), true);
        winMsgT = UIKit.Label(p.transform, "", 36, UIKit.Dark, TextAnchor.MiddleCenter, UIKit.A(0.08f, 0.17f, 0.92f, 0.3f));
        UIKit.Btn(p.transform, "PLAY AGAIN", UIKit.A(0.05f, 0.03f, 0.48f, 0.15f), UIKit.Hex("#51CF66"), () => gm.PlayAgain(), 48);
        UIKit.Btn(p.transform, "MAIN MENU", UIKit.A(0.52f, 0.03f, 0.95f, 0.15f), UIKit.Hex("#4DABF7"), () => gm.GoToMenu(), 48);

        GameObject cg = new GameObject("Confetti", typeof(RectTransform));
        cg.transform.SetParent(s, false);
        confettiRoot = cg.GetComponent<RectTransform>();
        UIKit.SetAnchors(confettiRoot, UIKit.A(0, 0, 1, 1));
        string[] cols = { "#FF3B3B", "#2F80FF", "#FFD93D", "#51CF66", "#FF8FAB", "#B197FC", "#FF922B" };
        for (int i = 0; i < 150; i++)
        {
            GameObject go = new GameObject("c", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(confettiRoot, false);
            Image im = go.GetComponent<Image>();
            im.color = UIKit.Hex(cols[i % cols.Length]);
            im.raycastTarget = false;
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = Vector2.zero;
            rt.sizeDelta = new Vector2(Random.Range(12f, 24f), Random.Range(8f, 16f));
            confetti.Add(new Piece { rt = rt, vx = Random.Range(-60f, 60f), vy = -Random.Range(140f, 380f), rot = Random.Range(0f, 360f), rotSpeed = Random.Range(-240f, 240f) });
        }
    }

    // ====================================================== refresh (state -> screens + text)
    void Vis(string key, bool on) { screens[key].target = on ? 1f : 0f; }

    void Refresh()
    {
        GameState s = gm.State;
        Vis("menu", s == GameState.Menu);
        Vis("settings", s == GameState.Settings);
        Vis("instructions", s == GameState.Instructions);
        Vis("class", s == GameState.ClassSelect);
        Vis("subject", s == GameState.SubjectSelect);
        Vis("setup", s == GameState.TeamSetup);
        bool hud = s == GameState.WaitingForRound || s == GameState.RoundReady || s == GameState.QuestionShown
                || s == GameState.Resolved || s == GameState.Paused || s == GameState.Finishing;
        Vis("hud", hud);
        Vis("pause", s == GameState.Paused);
        Vis("victory", s == GameState.Victory);

        foreach (System.Action r in volumeRefresh) r();
        subjectSub.text = "Class: " + QuestionLabels.ClassName(gm.SelectedClass);

        if (s == GameState.TeamSetup && prevState != GameState.TeamSetup)
        {
            redInput.text = ""; blueInput.text = "";
        }

        redNameT.text = gm.RedName; blueNameT.text = gm.BlueName;
        int r0 = gm.Score.RedScore, b0 = gm.Score.BlueScore;
        if (r0 > lastRed) redPop = 1f;
        if (b0 > lastBlue) bluePop = 1f;
        lastRed = r0; lastBlue = b0;
        redScoreT.text = r0.ToString(); blueScoreT.text = b0.ToString();
        roundT.text = gm.Round == 0 ? "GET READY!" : "ROUND " + gm.Round + " / " + gm.TotalRounds;
        string sub = gm.Current != null ? gm.Current.subjectLabel : QuestionLabels.SubjectName(gm.SelectedSubject);
        infoT.text = QuestionLabels.ClassName(gm.SelectedClass) + "  \u2022  " + sub + "  \u2022  FIRST TO " + gm.Score.WinningScore;
        hintT.text = Hint(s);

        bool banner = s == GameState.Resolved || s == GameState.Finishing;
        bannerBg.gameObject.SetActive(banner);
        if (banner)
        {
            bannerT.text = gm.LastResult;
            bannerBg.color = gm.LastScorer == TeamSide.Red ? Red : gm.LastScorer == TeamSide.Blue ? Blue : UIKit.Hex("#FF9F1C");
        }

        Fill(redQ, gm.Current != null ? gm.Current.red : null, gm.RedName, s);
        Fill(blueQ, gm.Current != null ? gm.Current.blue : null, gm.BlueName, s);

        if (s == GameState.Victory) FillVictory();
        if (s == GameState.Victory && prevState != GameState.Victory) ScatterConfetti();
        prevState = s;
    }

    string Hint(GameState s)
    {
        switch (s)
        {
            case GameState.WaitingForRound: return "Click START ROUND to begin!";
            case GameState.RoundReady: return "Click SHOW QUESTION";
            case GameState.QuestionShown: return "Read the questions aloud. Click the team that answers first!";
            case GameState.Resolved: return gm.IsLastRound ? "Last round done! Click FINISH GAME" : "Click NEXT ROUND to continue";
            case GameState.Finishing: return "What a pull!";
            default: return "";
        }
    }

    void Fill(QPanel p, QuestionData q, string teamName, GameState s)
    {
        bool ready = q != null && s == GameState.RoundReady;
        bool show = q != null && (s == GameState.QuestionShown || s == GameState.Resolved);
        p.root.gameObject.SetActive(ready || show);
        if (!(ready || show)) return;
        p.header.text = teamName;
        if (ready)
        {
            p.question.text = "Get ready!";
            p.visual.text = "";
            for (int i = 0; i < 4; i++) p.optBg[i].gameObject.SetActive(false);
            UIKit.SetAnchors(p.question.rectTransform, UIKit.A(0.04f, 0.1f, 0.96f, 0.87f));
            return;
        }
        bool hasVisual = !string.IsNullOrEmpty(q.visual);
        p.question.text = q.question;
        p.visual.text = hasVisual ? q.visual : "";
        UIKit.SetAnchors(p.question.rectTransform, hasVisual ? UIKit.A(0.04f, 0.62f, 0.96f, 0.87f) : UIKit.A(0.04f, 0.44f, 0.96f, 0.87f));
        string[] pastel = { "#FFF3BF", "#D0EBFF", "#FFD8E8", "#D3F9D8" };
        string letters = "ABCD";
        for (int i = 0; i < 4; i++)
        {
            bool has = i < q.options.Length;
            p.optBg[i].gameObject.SetActive(has);
            if (!has) continue;
            p.opt[i].text = letters[i] + ")  " + q.options[i];
            if (gm.AnswerRevealed)
            {
                bool ok = i == q.correctIndex;
                p.optBg[i].color = ok ? UIKit.Hex("#69DB7C") : new Color(0.93f, 0.93f, 0.95f);
                p.opt[i].fontStyle = ok ? FontStyle.Bold : FontStyle.Normal;
            }
            else
            {
                p.optBg[i].color = UIKit.Hex(pastel[i]);
                p.opt[i].fontStyle = FontStyle.Bold;
            }
        }
    }

    void FillVictory()
    {
        string rn = gm.RedName, bn = gm.BlueName;
        winScoreT.text = "FINAL SCORE:   " + rn + " " + gm.Score.RedScore + "  -  " + gm.Score.BlueScore + " " + bn;
        if (gm.IsDraw)
        {
            winHeader.text = "IT'S A TIE!";
            winNameT.text = "GREAT TEAMWORK!";
            winNameT.color = UIKit.Hex("#FF9F1C");
            winMsgT.text = "Both teams played brilliantly.\nEveryone is a champion!";
        }
        else
        {
            bool redWon = gm.Winner == TeamSide.Red;
            winHeader.text = "WINNER!";
            winNameT.text = redWon ? rn : bn;
            winNameT.color = redWon ? Red : Blue;
            winMsgT.text = "Great effort, " + (redWon ? bn : rn) + "!\nYou played really well. Keep learning and you can win next time!";
        }
    }

    void ScatterConfetti()
    {
        Rect r = confettiRoot.rect;
        float W = r.width > 1 ? r.width : 1920f, H = r.height > 1 ? r.height : 1080f;
        foreach (Piece c in confetti) c.rt.anchoredPosition = new Vector2(Random.Range(0, W), Random.Range(0, H));
    }

    // ====================================================== per-frame animation
    void Update()
    {
        foreach (UIScreen sc in screens.Values)
        {
            sc.group.alpha = Mathf.MoveTowards(sc.group.alpha, sc.target, Time.unscaledDeltaTime * 5f);
            bool visible = sc.group.alpha > 0.01f || sc.target > 0f;
            if (sc.group.gameObject.activeSelf != visible) sc.group.gameObject.SetActive(visible);
            sc.group.blocksRaycasts = sc.target > 0.5f;
            sc.rt.localScale = Vector3.one * Mathf.Lerp(0.94f, 1f, sc.group.alpha);
        }
        if (titleRt != null) titleRt.localScale = Vector3.one * (1f + Mathf.Sin(Time.time * 2.2f) * 0.03f);

        redPop = Mathf.MoveTowards(redPop, 0f, Time.deltaTime * 1.6f);
        bluePop = Mathf.MoveTowards(bluePop, 0f, Time.deltaTime * 1.6f);
        if (redScoreT != null) redScoreT.transform.localScale = Vector3.one * (1f + 0.6f * redPop);
        if (blueScoreT != null) blueScoreT.transform.localScale = Vector3.one * (1f + 0.6f * bluePop);

        if (gm != null && gm.State == GameState.Victory)
        {
            if (trophyRt != null)
            {
                trophyRt.localScale = Vector3.one * (1f + Mathf.Sin(Time.time * 4f) * 0.06f);
                trophyRt.localRotation = Quaternion.Euler(0, 0, Mathf.Sin(Time.time * 3f) * 4f);
            }
            Rect r = confettiRoot.rect;
            float W = r.width > 1 ? r.width : 1920f, H = r.height > 1 ? r.height : 1080f;
            foreach (Piece c in confetti)
            {
                Vector2 pos = c.rt.anchoredPosition;
                pos.x += (c.vx + Mathf.Sin(Time.time * 2f + c.rot) * 40f) * Time.deltaTime;
                pos.y += c.vy * Time.deltaTime;
                if (pos.y < -30f) { pos.y = H + 30f; pos.x = Random.Range(0, W); }
                c.rt.anchoredPosition = pos;
                c.rt.localRotation = Quaternion.Euler(0, 0, c.rot + Time.time * c.rotSpeed);
            }
        }
    }
}
